Please answer these questions before submitting your issue. Thanks!

### What version of shadowsocks-libev are you using?


### What operating system are you using?


### What did you do?


### What did you expect to see?


### What did you see instead?


### What is your config in detail (with all sensitive info masked)?
